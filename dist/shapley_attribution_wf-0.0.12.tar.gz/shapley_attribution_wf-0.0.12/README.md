This is a method based on project: https://github.com/ianchute/shapley-attribution-model-zhao-naive.

The main difference is put in a shapley attribution for fixed formular.

The three method are:

shapley_attribution_formula.ShapleyAttributionModelFormula
shapley_attribution_ads.OrderedShapleyAttributionModel
shapley_attribution_ads.SimplifiedShapleyAttributionModel

You can just import and instantiate it.
